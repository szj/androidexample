package com.ch_linghu.fanfoudroid.db2;

public class FanDatabaseException extends Exception {
	private static final long serialVersionUID = -6901538163576215658L;

	public FanDatabaseException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FanDatabaseException(String detailMessage, Throwable throwable) {
		super(detailMessage, throwable);
		// TODO Auto-generated constructor stub
	}

	public FanDatabaseException(String detailMessage) {
		super(detailMessage);
		// TODO Auto-generated constructor stub
	}

	public FanDatabaseException(Throwable throwable) {
		super(throwable);
		// TODO Auto-generated constructor stub
	}

}
