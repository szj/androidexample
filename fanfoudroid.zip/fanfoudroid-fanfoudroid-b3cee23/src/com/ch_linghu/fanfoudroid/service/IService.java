package com.ch_linghu.fanfoudroid.service;

public interface IService {
	void startService();

	void stopService();
}
