package com.ch_linghu.fanfoudroid.ui.module;

public interface IFlipper {
	void showNext();

	void showPrevious();
}
