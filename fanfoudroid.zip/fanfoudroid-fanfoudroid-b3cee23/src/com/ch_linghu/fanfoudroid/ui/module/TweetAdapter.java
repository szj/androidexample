package com.ch_linghu.fanfoudroid.ui.module;

import android.widget.ListAdapter;

public interface TweetAdapter extends ListAdapter {
	void refresh();
}
